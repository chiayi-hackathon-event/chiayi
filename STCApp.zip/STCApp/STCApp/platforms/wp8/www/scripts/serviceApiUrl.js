﻿var apiPath = "https://www.stcgo.com.tw/slnTCWeb/prjTCWeb/api/";

